#!/usr/bin/env bash
# VALIDATOR | Correção automatizada do laboratório Linux
# Debian / AlmaLinux | Apache / NGINX | Nota automatizada: 8,0 pontos

set -o pipefail
export LC_ALL=C

API_URL="https://script.google.com/macros/s/AKfycbwQxGec6LPqAdP2pbOHjUyOLHRF_Qx_sNgEwex3pZq4DCi6tNhNokl2AnmvzZadMaT9LQ/exec"
WEB_ROOT="/var/www/html"
SCORE="0.0"
FAILURES=()

# Cores do terminal
if [[ -t 1 ]]; then
  GREEN=$'\033[1;32m'
  CYAN=$'\033[1;96m'
  RED=$'\033[1;31m'
  YELLOW=$'\033[1;33m'
  WHITE=$'\033[1;37m'
  BOLD=$'\033[1m'
  DIM=$'\033[2m'
  RESET=$'\033[0m'
  BG_BLUE=$'\033[48;5;27m'
  BG_GREEN=$'\033[48;5;28m'
  BG_RED=$'\033[48;5;124m'
  BG_YELLOW=$'\033[48;5;214m'
else
  GREEN='' CYAN='' RED='' YELLOW='' WHITE='' BOLD='' DIM='' RESET=''
  BG_BLUE='' BG_GREEN='' BG_RED='' BG_YELLOW=''
fi

print_divider() {
  printf " ${DIM}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}\\n"
}

print_section() {
  printf "\\n ${CYAN}╭──────────────────────────────────────────────────────────────╮${RESET}\\n"
  printf " ${CYAN}│${RESET}  ${WHITE}${BOLD}%-58s${RESET} ${CYAN}│${RESET}\\n" "$1"
  printf " ${CYAN}╰──────────────────────────────────────────────────────────────╯${RESET}\\n"
}

status_banner() {
  printf "\\n ${BG_GREEN}${WHITE}${BOLD}  %-58s  ${RESET}\\n" "$1"
}

# Mensagens padronizadas utilizadas durante a coleta e a avaliação.
log_info() {
  printf " ${CYAN}•${RESET} %s\\n" "$1"
}

log_success() {
  printf " ${GREEN}✔${RESET} %s\\n" "$1"
}

log_warning() {
  printf " ${YELLOW}⚠ Aviso:${RESET} %s\\n" "$1"
}

log_error() {
  printf " ${RED}✖ Erro:${RESET} %s\\n" "$1"
}

add_score() {
  local points="${1/,/.}"
  SCORE=$(awk -v s="$SCORE" -v p="$points" 'BEGIN { printf "%.1f", s+p }')
}

pass_item() {
  printf " ${GREEN}✔${RESET}  %-43s ${GREEN}%4s pt(s)${RESET}\n" "$1" "$2"
  add_score "$2"
}

fail_item() {
  printf " ${RED}✖${RESET}  %-43s ${RED}%4s pt(s)${RESET}\n" "$1" "0,0"
  FAILURES+=("$2")
}

header() {
  clear 2>/dev/null || printf '\033[2J\033[H'
  printf "\n"
  printf " ${CYAN}╔══════════════════════════════════════════════════════════════╗${RESET}\n"
  printf " ${CYAN}║${RESET}  ${BG_BLUE}${WHITE}${BOLD}       VALIDATOR · LABORATÓRIO LINUX       ${RESET}               ${CYAN}║${RESET}\n"
  printf " ${CYAN}║${RESET}  ${WHITE}Avaliação de infraestrutura · Debian / AlmaLinux${RESET}        ${CYAN}║${RESET}\n"
  printf " ${CYAN}╚══════════════════════════════════════════════════════════════╝${RESET}\n"
  printf " ${DIM}                     LINUX LAB ASSESSMENT${RESET}\n\n"
}


detect_real_distro() {
  REAL_DISTRO="unknown"

  # Debian: prioriza o identificador oficial; usa /etc/issue como alternativa.
  if [[ -r /etc/os-release ]] && grep -Eiq '^ID=debian$' /etc/os-release; then
    REAL_DISTRO="debian"
  elif [[ -r /etc/issue ]] && grep -Eiq 'debian' /etc/issue; then
    REAL_DISTRO="debian"
  elif [[ -r /etc/debian_version ]] && [[ -r /etc/os-release ]] &&
       grep -Eiq '^ID_LIKE=.*debian' /etc/os-release &&
       ! grep -Eiq '^ID=ubuntu$' /etc/os-release; then
    REAL_DISTRO="debian"
  fi

  # AlmaLinux: identifica pelo conteúdo de /etc/redhat-release ou /etc/issue.
  if [[ -r /etc/redhat-release ]] && grep -Eiq 'AlmaLinux' /etc/redhat-release; then
    REAL_DISTRO="almalinux"
  elif [[ "$REAL_DISTRO" == "unknown" && -r /etc/issue ]] &&
       grep -Eiq 'AlmaLinux' /etc/issue; then
    REAL_DISTRO="almalinux"
  fi
}

check_distribution() {
  detect_real_distro
  case "$DIST_CHOICE" in
    1) SELECTED_DISTRO="debian"; DIST_LABEL="Debian" ;;
    2) SELECTED_DISTRO="almalinux"; DIST_LABEL="AlmaLinux" ;;
  esac

  if [[ "$REAL_DISTRO" == "$SELECTED_DISTRO" ]]; then
    printf " ${GREEN}✔${RESET}  Distribuição confirmada: ${WHITE}%s${RESET}\n\n" "$DIST_LABEL"
  else
    printf "\n ${RED}ERRO: distribuição selecionada incompatível.${RESET}\n"
    case "$REAL_DISTRO" in
      debian) printf " Sistema identificado: Debian.\n" ;;
      almalinux) printf " Sistema identificado: AlmaLinux.\n" ;;
      *) printf " Não foi possível identificar Debian ou AlmaLinux neste sistema.\n" ;;
    esac
    printf " Selecione a distribuição correta e execute novamente.\n\n"
    exit 1
  fi
}

# Lê a configuração efetiva do BIND, incluindo arquivos incluídos.
dns_config_dump() {
  if command -v named-checkconf >/dev/null 2>&1; then
    if [[ "$SELECTED_DISTRO" == "debian" ]]; then
      named-checkconf -p /etc/bind/named.conf 2>/dev/null
    else
      named-checkconf -p /etc/named.conf 2>/dev/null
    fi
  else
    if [[ "$SELECTED_DISTRO" == "debian" ]]; then
      cat /etc/bind/named.conf /etc/bind/named.conf.options /etc/bind/named.conf.local 2>/dev/null
    else
      cat /etc/named.conf 2>/dev/null
    fi
  fi
}

check_ip() {
  local found="no"
  if [[ "$SELECTED_DISTRO" == "debian" ]]; then
    if [[ -r /etc/network/interfaces ]] &&
       grep -Eiq '^[[:space:]]*iface[[:space:]]+[^[:space:]]+[[:space:]]+inet[[:space:]]+static([[:space:]]|$)' /etc/network/interfaces; then
      found="yes"
    fi
  elif command -v nmcli >/dev/null 2>&1; then
    local uuid data method addresses
    while IFS= read -r uuid; do
      [[ -n "$uuid" ]] || continue
      data=$(nmcli -g ipv4.method,ipv4.addresses connection show "$uuid" 2>/dev/null)
      method=$(printf '%s\n' "$data" | head -n1)
      addresses=$(printf '%s\n' "$data" | sed -n '2p')
      if [[ "$method" == "manual" && -n "$addresses" ]]; then
        found="yes"
        break
      fi
    done < <(nmcli -t -f UUID connection show --active 2>/dev/null)
  fi

  if [[ "$found" == "yes" ]]; then
    pass_item "IP fixo configurado" "1,0"
  else
    fail_item "IP fixo não identificado" "IP fixo não identificado."
  fi
}

check_dns_service() {
  if systemctl is-active --quiet "$DNS_SERVICE" 2>/dev/null; then
    pass_item "Servidor DNS instalado e ativo" "1,0"
  else
    fail_item "Servidor DNS ausente ou inativo" "Servidor DNS não está ativo."
  fi
}

check_dns_zone() {
  local dump
  dump=$(dns_config_dump)
  if printf '%s\n' "$dump" | grep -Eiq 'zone[[:space:]]+"[^"]+\.lab"[[:space:]]*(IN[[:space:]]*)?\{'; then
    pass_item "Domínio .lab configurado" "1,0"
  else
    fail_item "Domínio .lab não identificado" "Zona DNS com sufixo .lab não identificada."
  fi
}

detect_web_service() {
  WEB_SERVICE=""
  WEB_KIND=""
  if systemctl is-active --quiet apache2 2>/dev/null; then
    WEB_SERVICE="apache2"; WEB_KIND="apache"
  elif systemctl is-active --quiet httpd 2>/dev/null; then
    WEB_SERVICE="httpd"; WEB_KIND="apache"
  elif systemctl is-active --quiet nginx 2>/dev/null; then
    WEB_SERVICE="nginx"; WEB_KIND="nginx"
  elif systemctl list-unit-files apache2.service httpd.service 2>/dev/null | grep -qE 'apache2\.service|httpd\.service'; then
    if systemctl list-unit-files apache2.service 2>/dev/null | grep -q apache2.service; then
      WEB_SERVICE="apache2"
    else
      WEB_SERVICE="httpd"
    fi
    WEB_KIND="apache"
  elif systemctl list-unit-files nginx.service 2>/dev/null | grep -q nginx.service; then
    WEB_SERVICE="nginx"; WEB_KIND="nginx"
  fi
}

check_web_service() {
  detect_web_service
  if [[ -n "$WEB_SERVICE" ]] && systemctl is-active --quiet "$WEB_SERVICE" 2>/dev/null; then
    pass_item "Servidor HTTP ($WEB_SERVICE) ativo" "1,0"
  else
    fail_item "Apache/NGINX ausente ou inativo" "Servidor Apache ou NGINX não está ativo."
  fi
}

check_html() {
  if [[ -f "$WEB_ROOT/index.html" ]] &&
     find "$WEB_ROOT" -mindepth 1 ! -name index.html -print -quit 2>/dev/null | grep -q .; then
    pass_item "Template HTML publicado" "1,0"
  else
    fail_item "Template HTML incompleto" "index.html ou conteúdo adicional não identificado em /var/www/html."
  fi
}

check_web_security() {
  local ok="no"
  if [[ "$WEB_KIND" == "apache" ]]; then
    local apache_dir
    if [[ "$WEB_SERVICE" == "apache2" ]]; then apache_dir="/etc/apache2"; else apache_dir="/etc/httpd"; fi
    if grep -RIEq --include='*.conf' '^[[:space:]]*ServerTokens[[:space:]]+Prod([[:space:]]|$)' "$apache_dir" 2>/dev/null; then
      ok="yes"
    fi
  elif [[ "$WEB_KIND" == "nginx" ]] && command -v nginx >/dev/null 2>&1; then
    if nginx -T 2>/dev/null | grep -Eiq '^[[:space:]]*server_tokens[[:space:]]+off[[:space:]]*;'; then
      ok="yes"
    fi
  fi

  if [[ "$ok" == "yes" ]]; then
    pass_item "Segurança do servidor Web" "1,0"
  else
    fail_item "Segurança do servidor Web não identificada" "Diretiva de ocultação da versão do servidor Web não identificada."
  fi
}

check_dns_recursion() {
  local dump compact
  dump=$(dns_config_dump)
  # named-checkconf -p normaliza a configuração e expande includes.
  # awk une as linhas; evita expressão sed que falhava com delimitadores.
  compact=$(printf '%s\n' "$dump" | awk '{ printf "%s ", $0 }')
  if printf '%s\n' "$compact" | grep -Eiq '(^|[;{}[:space:]])recursion[[:space:]]+no[[:space:]]*;'; then
    pass_item "DNS Recursivo" "0,5"
  else
    fail_item "DNS Recursivo não configurado" "Diretiva para impedir DNS recursivo não identificada."
  fi
}

check_dns_transfer() {
  local dump compact
  dump=$(dns_config_dump)
  compact=$(printf '%s\n' "$dump" | awk '{ printf "%s ", $0 }')
  if printf '%s\n' "$compact" | grep -Eiq 'allow-transfer[[:space:]]*\{[[:space:]]*none[[:space:]]*;[[:space:]]*\}[[:space:]]*;'; then
    pass_item "DNS: Zone Transfer Bloqueado" "0,5"
  else
    fail_item "DNS: Zone Transfer não bloqueado" "Diretiva DNS para impedir a transferência de zona não identificada."
  fi
}

check_startup() {
  if [[ "$(systemctl is-enabled "$DNS_SERVICE" 2>/dev/null)" == "enabled" ]]; then
    pass_item "DNS habilitado na inicialização" "0,5"
  else
    fail_item "DNS não habilitado na inicialização" "Serviço DNS não está habilitado na inicialização."
  fi

  if [[ -n "$WEB_SERVICE" ]] && [[ "$(systemctl is-enabled "$WEB_SERVICE" 2>/dev/null)" == "enabled" ]]; then
    pass_item "HTTP habilitado na inicialização" "0,5"
  else
    fail_item "HTTP não habilitado na inicialização" "Serviço HTTP não está habilitado na inicialização."
  fi
}

show_report() {
  print_section "RELATÓRIO DE VERIFICAÇÃO DO AMBIENTE"
  printf " ${DIM}Cada critério é avaliado individualmente conforme a rubrica.${RESET}\n\n"

  check_ip
  check_dns_service
  check_dns_zone
  check_web_service
  check_html
  check_web_security
  check_dns_recursion
  check_dns_transfer
  check_startup

  local percent
  percent=$(awk -v s="$SCORE" 'BEGIN { printf "%.2f", (s/8)*100 }')
  printf "\n ${CYAN}╔══════════════════════════════════════════════════════════════╗${RESET}\n"
  printf " ${CYAN}║${RESET}  ${WHITE}${BOLD}NOTA AUTOMATIZADA${RESET}       ${BG_GREEN}${WHITE}${BOLD}  %s / 8,0  ${RESET}                         ${CYAN}║${RESET}\n" "$SCORE"
  printf " ${CYAN}║${RESET}  ${WHITE}${BOLD}APROVEITAMENTO${RESET}          ${GREEN}${BOLD}%s%%${RESET}                                  ${CYAN}║${RESET}\n" "$percent"
  printf " ${CYAN}╚══════════════════════════════════════════════════════════════╝${RESET}\n"

  if ((${#FAILURES[@]})); then
    printf "\n ${YELLOW}ITENS NÃO IDENTIFICADOS:${RESET}\n"
    local item
    for item in "${FAILURES[@]}"; do
      printf " ${RED}•${RESET} %s\n" "$item"
    done
  else
    printf "\n ${GREEN}Todos os critérios automatizados foram atendidos.${RESET}\n"
  fi
}

valid_name() {
  local words
  words=$(awk '{$1=$1; print NF}' <<< "$1")
  (( words >= 2 ))
}

valid_email() {
  local email_re='^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
  [[ "$1" =~ $email_re ]]
}

valid_rm() {
  [[ "$1" =~ ^[0-9]+$ ]]
}

trim_value() {
  local value="$1"
  value="${value#"${value%%[![:space:]]*}"}"
  value="${value%"${value##*[![:space:]]}"}"
  printf '%s' "$value"
}

collect_student_data() {
  print_section "IDENTIFICAÇÃO DO ALUNO"
  printf " ${DIM}Cada informação será validada assim que for digitada.${RESET}\n\n"

  while true; do
    read -r -p " ${CYAN}Turma:${RESET} " TURMA
    TURMA=$(trim_value "$TURMA")
    if [[ -n "$TURMA" ]]; then
      log_success "Turma validada."
      break
    fi
    log_error "A turma é obrigatória. Informe novamente."
  done

  while true; do
    read -r -p " ${CYAN}Nome completo:${RESET} " NOME
    NOME=$(trim_value "$NOME")
    if valid_name "$NOME"; then
      log_success "Nome completo validado."
      break
    fi
    log_error "Informe nome e sobrenome (mínimo de duas palavras)."
  done

  while true; do
    read -r -p " ${CYAN}E-mail:${RESET} " EMAIL
    EMAIL=$(trim_value "$EMAIL")
    if valid_email "$EMAIL"; then
      log_success "Formato do e-mail validado."
      break
    fi
    log_error "E-mail inválido. Confira o endereço e tente novamente."
  done

  while true; do
    read -r -p " ${CYAN}RM (somente números):${RESET} " RM
    RM=$(trim_value "$RM")
    if valid_rm "$RM"; then
      log_success "RM validado."
      break
    fi
    log_error "RM inválido. Utilize somente números."
  done

  status_banner "DADOS DO ALUNO VALIDADOS"
  printf "\n"
}

make_payload() {
  TURMA="$TURMA" NOME="$NOME" EMAIL="$EMAIL" RM="$RM" NOTA="$PERCENT" python3 - <<'PY'
import json, os
print(json.dumps({
    "turma": os.environ["TURMA"],
    "nome": os.environ["NOME"],
    "email": os.environ["EMAIL"],
    "rm": os.environ["RM"],
    "nota": float(os.environ["NOTA"])
}, ensure_ascii=False))
PY
}

send_grade() {
  collect_student_data

  if ! command -v curl >/dev/null 2>&1; then
    printf "\n ${RED}curl não está instalado. O script foi preservado.${RESET}\n"
    return 1
  fi
  if ! command -v python3 >/dev/null 2>&1; then
    printf "\n ${RED}python3 não está instalado. O script foi preservado.${RESET}\n"
    return 1
  fi

  local payload result http_code response self_path
  payload=$(make_payload) || {
    printf "\n ${RED}Não foi possível preparar os dados. O script foi preservado.${RESET}\n"
    return 1
  }

  printf "\n ${CYAN}Enviando avaliação para a planilha...${RESET}\n"
  # Não usar -X POST: o Apps Script pode redirecionar a resposta do POST
  # para script.googleusercontent.com, que deve ser consultado por GET.
  result=$(curl --silent --show-error --location --max-redirs 8 \
    --connect-timeout 15 --max-time 60 \
    --header "Content-Type: application/json; charset=utf-8" \
    --data-binary "$payload" \
    --write-out $'\n%{http_code}' \
    "$API_URL" 2>&1)
  local curl_status=$?

  http_code="${result##*$'\n'}"
  response="${result%$'\n'*}"

  if (( curl_status == 0 )) &&
     [[ "$http_code" =~ ^2[0-9][0-9]$ ]] &&
     printf '%s' "$response" | grep -Eiq '"status"[[:space:]]*:[[:space:]]*"success"'; then
    printf "\n ${GREEN}✔ Nota enviada com sucesso!${RESET}\n"
    printf " ${GREEN}Percentual registrado: %s%%${RESET}\n" "$PERCENT"
    self_path=$(readlink -f -- "${BASH_SOURCE[0]}" 2>/dev/null)
    if [[ -n "$self_path" && -f "$self_path" ]] && rm -f -- "$self_path"; then
      printf " ${GREEN}script-validator.sh removido após confirmação da API.${RESET}\n"
    else
      printf " ${YELLOW}A API confirmou o envio, mas o arquivo não pôde ser removido automaticamente.${RESET}\n"
    fi
    exit 0
  fi

  printf "\n ${RED}Falha no envio. O script foi preservado.${RESET}\n"
  printf " ${YELLOW}HTTP: %s | curl: %s${RESET}\n" "${http_code:-indisponível}" "$curl_status"
  if [[ -n "$response" ]]; then
    printf " ${DIM}Resposta (trecho):${RESET}\n"
    printf '%s\n' "$response" | head -c 700
    printf "\n"
  fi
  printf " ${YELLOW}Verifique a implantação e a permissão de acesso da Web App do Google Apps Script.${RESET}\n"
  return 1
}

main() {
  header

  if [[ $EUID -ne 0 ]]; then
    printf " ${YELLOW}Aviso: execute com sudo para ler todas as configurações.${RESET}\n\n"
  fi

  printf " ${WHITE}Qual distribuição está sendo utilizada?${RESET}\n"
  printf "   ${GREEN}1${RESET}  Debian\n"
  printf "   ${CYAN}2${RESET}  AlmaLinux\n\n"
  read -r -p " Selecione 1 ou 2: " DIST_CHOICE

  case "$DIST_CHOICE" in
    1) DIST_LABEL="Debian"; SELECTED_DISTRO="debian"; DNS_SERVICE="bind9" ;;
    2) DIST_LABEL="AlmaLinux"; SELECTED_DISTRO="almalinux"; DNS_SERVICE="named" ;;
    *) printf "\n ${RED}Opção inválida. Execute novamente.${RESET}\n"; exit 1 ;;
  esac

  check_distribution

  if [[ "$SELECTED_DISTRO" == "debian" ]] && ! systemctl list-unit-files bind9.service 2>/dev/null | grep -q bind9.service; then
    DNS_SERVICE="named"
  fi

  printf " ${DIM}Sistema: %s | DNS: %s | Diretório Web: %s${RESET}\n\n" "$DIST_LABEL" "$DNS_SERVICE" "$WEB_ROOT"
  show_report

  local answer
  while true; do
    printf "\n"
    read -r -p " Deseja encerrar a tarefa e enviar a nota/percentual atual? [s ou n] " answer
    case "$answer" in
      [sS]) break ;;
      [nN])
        printf "\n ${CYAN}Validação encerrada. Você poderá executar o script novamente após as correções.${RESET}\n"
        exit 0
        ;;
      *) printf " ${YELLOW}Digite 's' para enviar ou 'n' para voltar a tarefa:${RESET}\n" ;;
    esac
  done

  PERCENT=$(awk -v s="$SCORE" 'BEGIN { printf "%.2f", (s/8)*100 }')
  send_grade
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  main "$@"
fi
