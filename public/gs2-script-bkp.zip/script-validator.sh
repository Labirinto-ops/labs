#!/bin/bash
###############################################################################
# Desafio: Deploy de servidor Web (Apache/NGINX) + DNS (BIND) + site HTML
#          Debian / AlmaLinux  -  Nota de 0 a 8
# Validador de configuracao - gerado por skill validador-linux-shc
###############################################################################

# PATH fixo e restrito: evita que um binario malicioso no PATH do usuario
# (ex.: um "curl" falso que sempre responde "success") seja executado no
# lugar do utilitario real do sistema. NAO REMOVER.
PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PATH

# ---------------------------------------------------------------------------
# Locale: fixa um locale UTF-8 (mensagens dos utilitarios em ingles, o que
# estabiliza o parsing) e descobre se o terminal do aluno suporta UTF-8.
# ---------------------------------------------------------------------------
_ORIG_LOCALE="${LC_ALL:-${LC_CTYPE:-${LANG:-}}}"
for _l in C.UTF-8 C.utf8 en_US.UTF-8 en_US.utf8; do
    if locale -a 2>/dev/null | grep -qix -- "$_l"; then
        export LC_ALL="$_l"
        break
    fi
done

UI_UTF8=0
case "$_ORIG_LOCALE" in *[Uu][Tt][Ff]-8* | *[Uu][Tt][Ff]8*) UI_UTF8=1 ;; esac
[ "${TERM:-}" = "linux" ] && UI_UTF8=0   # console puro da VM: visual simples

# ---------------------------------------------------------------------------
# Cores (256 cores, 8 cores ou nenhuma; respeita NO_COLOR e saida sem TTY)
# ---------------------------------------------------------------------------
NCOLORS=0
if [ -t 1 ] && [ -z "${NO_COLOR:-}" ] && [ -n "${TERM:-}" ] && [ "$TERM" != "dumb" ]; then
    NCOLORS=$(tput colors 2>/dev/null)
    [[ "$NCOLORS" =~ ^[0-9]+$ ]] || NCOLORS=8
fi

if [ "$NCOLORS" -ge 256 ]; then
    RED=$'\033[38;5;203m'; GREEN=$'\033[38;5;84m'; YELLOW=$'\033[38;5;221m'
    CYAN=$'\033[38;5;51m'; BLUE=$'\033[38;5;39m'; WHITE=$'\033[38;5;255m'
    GRAY=$'\033[38;5;245m'
elif [ "$NCOLORS" -ge 8 ]; then
    RED=$'\033[0;31m'; GREEN=$'\033[0;32m'; YELLOW=$'\033[1;33m'
    CYAN=$'\033[0;36m'; BLUE=$'\033[0;34m'; WHITE=$'\033[1;37m'
    GRAY=$'\033[2m'
else
    RED=''; GREEN=''; YELLOW=''; CYAN=''; BLUE=''; WHITE=''; GRAY=''
fi
if [ "$NCOLORS" -ge 8 ]; then BOLD=$'\033[1m'; NC=$'\033[0m'; else BOLD=''; NC=''; fi

# Degrade vermelho -> amarelo -> verde (usado nas barras em 256 cores)
GRAD=(196 202 208 214 220 226 190 154 118 82 46)

# ---------------------------------------------------------------------------
# Glifos (UTF-8 ou ASCII)
# ---------------------------------------------------------------------------
if [ "$UI_UTF8" -eq 1 ]; then
    G_OK='✔'; G_KO='✖'; G_PART='◐'; G_FULL='█'; G_EMPTY='░'; G_H='─'; G_HH='═'
    G_V='║'; G_TL='╔'; G_TR='╗'; G_BL='╚'; G_BR='╝'; G_BLK='▌'; G_DOT='•'
else
    G_OK='+'; G_KO='x'; G_PART='~'; G_FULL='#'; G_EMPTY='-'; G_H='-'; G_HH='='
    G_V='|'; G_TL='+'; G_TR='+'; G_BL='+'; G_BR='+'; G_BLK='>'; G_DOT='*'
fi

BANNER=(
'██╗   ██╗ █████╗ ██╗     ██╗██████╗  █████╗ ████████╗ ██████╗ ██████╗ '
'██║   ██║██╔══██╗██║     ██║██╔══██╗██╔══██╗╚══██╔══╝██╔═══██╗██╔══██╗'
'██║   ██║███████║██║     ██║██║  ██║███████║   ██║   ██║   ██║██████╔╝'
'╚██╗ ██╔╝██╔══██║██║     ██║██║  ██║██╔══██║   ██║   ██║   ██║██╔══██╗'
' ╚████╔╝ ██║  ██║███████╗██║██████╔╝██║  ██║   ██║   ╚██████╔╝██║  ██║'
'  ╚═══╝  ╚═╝  ╚═╝╚══════╝╚═╝╚═════╝ ╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝'
)

# ---------------------------------------------------------------------------
# >>> VARIAVEIS DO DESAFIO <<<
# Caminhos consultados pelos checks.
# ---------------------------------------------------------------------------
ISSUE_F=/etc/issue
DEBVER_F=/etc/debian_version
RHREL_F=/etc/redhat-release
ALMAREL_F=/etc/almalinux-release
OSREL_F=/etc/os-release
IFACES_F=/etc/network/interfaces
IFACES_D=/etc/network/interfaces.d
IFCFG_D=/etc/sysconfig/network-scripts
BIND_DEB_DIR=/etc/bind
NAMED_ALMA_CONF=/etc/named.conf
ZONE_DIRS="/var/named /var/cache/bind /etc/bind"
WEBROOT=/var/www/html
NGINX_ROOT=/usr/share/nginx/html
APACHE_DEB_DIR=/etc/apache2
APACHE_RH_DIR=/etc/httpd
# >>> FIM VARIAVEIS DO DESAFIO <<<

# ---------------------------------------------------------------------------
# Arrays de controle
#   SCORES[i] -> pontos obtidos no item i
#   MAXS[i]   -> pontos maximos do item i  (soma de todos = 8,0)
#   LABEL[i]  -> texto exibido na tabela
#   PEND[i]   -> texto SUPERFICIAL exibido quando o item nao foi validado
#                (sem diretivas nem locais de configuracao)
# ---------------------------------------------------------------------------
declare -A SCORES MAXS LABEL PEND

MAXS=([1]=1 [2]=1 [3]=1 [4]=1 [5]=1 [6]=1 [7]=0.5 [8]=0.5 [9]=0.5 [10]=0.5)

LABEL[1]="Endereço IP fixo configurado"
LABEL[2]="Servidor DNS instalado e ativo"
LABEL[3]="Domínio .lab publicado no DNS"
LABEL[4]="Servidor HTTP instalado e ativo"
LABEL[5]="Template HTML publicado"
LABEL[6]="Segurança Web: versão ocultada"
LABEL[7]="Segurança DNS: recursão"
LABEL[8]="Segurança DNS: transferência de zona"
LABEL[9]="DNS inicia com o sistema"
LABEL[10]="Servidor Web inicia com o sistema"

PEND[1]="Endereço IP fixo"
PEND[2]="Servidor DNS (instalação e funcionamento)"
PEND[3]="Domínio .lab no servidor DNS"
PEND[4]="Servidor HTTP (instalação e funcionamento)"
PEND[5]="Publicação do template HTML"
PEND[6]="Segurança do servidor Web"
PEND[7]="Segurança do DNS: recursão"
PEND[8]="Segurança do DNS: transferência de zona"
PEND[9]="Inicialização automática do servidor DNS"
PEND[10]="Inicialização automática do servidor Web"

# Blocos de pontuacao (nome, primeiro item, ultimo item)
BLK_NAME=("REDE" "DNS" "SERVIDOR WEB" "SEGURANÇA" "INICIALIZAÇÃO")
BLK_START=(1 2 4 6 9)
BLK_END=(1 3 5 8 10)
TOTAL_ITENS=10
NOTA_MAXIMA=8

# ---------------------------------------------------------------------------
# Utilitarios genericos
# ---------------------------------------------------------------------------
clean_num() {
    local v="$1"
    [ -z "$v" ] && v=0
    echo "$v"
}

rep() { local s="" i; for ((i = 0; i < $2; i++)); do s+="$1"; done; printf '%s' "$s"; }

pad() {
    local t="$1" w="$2" n
    n=$((w - ${#t}))
    [ "$n" -lt 0 ] && n=0
    printf '%s%*s' "$t" "$n" ""
}

# 6.5 -> "6,5"
fmtn() { awk -v v="$1" 'BEGIN{printf "%.1f", v}' | tr '.' ','; }

grant() { SCORES[$1]="${MAXS[$1]}"; }
deny()  { SCORES[$1]=0; }

# ---------------------------------------------------------------------------
# Soma de um intervalo de itens (pontos obtidos / pontos maximos)
# ---------------------------------------------------------------------------
sum_range() {
    local start="$1" end="$2" total=0 i
    for ((i = start; i <= end; i++)); do
        total=$(awk -v t="$total" -v s="${SCORES[$i]:-0}" 'BEGIN{printf "%.2f", t+s}')
    done
    echo "$total"
}

sum_max_range() {
    local start="$1" end="$2" total=0 i
    for ((i = start; i <= end; i++)); do
        total=$(awk -v t="$total" -v s="${MAXS[$i]}" 'BEGIN{printf "%.2f", t+s}')
    done
    echo "$total"
}

# ---------------------------------------------------------------------------
# Visual: barra em degrade, spinner, caixas
# ---------------------------------------------------------------------------
bar_build() {   # $1 = percentual, $2 = largura -> variavel BAR
    local pct="$1" w="$2" filled i idx out="" basic
    filled=$(awk -v p="$pct" -v w="$w" 'BEGIN{f=int(p/100*w+0.5); if(f>w)f=w; if(f<0)f=0; print f}')
    if awk -v p="$pct" 'BEGIN{exit !(p>=100)}'; then basic=$GREEN
    elif awk -v p="$pct" 'BEGIN{exit !(p>=60)}'; then basic=$YELLOW
    else basic=$RED; fi
    for ((i = 0; i < w; i++)); do
        if ((i < filled)); then
            if [ "$NCOLORS" -ge 256 ]; then
                idx=$((i * (${#GRAD[@]} - 1) / (w > 1 ? w - 1 : 1)))
                out+=$'\033[38;5;'"${GRAD[idx]}"'m'"$G_FULL"
            else
                out+="${basic}${G_FULL}"
            fi
        else
            out+="${GRAY}${G_EMPTY}"
        fi
    done
    BAR="${out}${NC}"
}

spin() {   # animacao curta antes de cada verificacao (somente em TTY)
    [ -t 1 ] || return 0
    local frames i
    if [ "$UI_UTF8" -eq 1 ]; then frames=(⠋ ⠙ ⠹ ⠸ ⠼ ⠴ ⠦ ⠧ ⠇ ⠏); else frames=('|' '/' '-' '\'); fi
    printf '\033[?25l'
    for ((i = 0; i < 9; i++)); do
        printf '\r    %s%s%s  %s' "$CYAN" "${frames[i % ${#frames[@]}]}" "$NC" "$1"
        sleep 0.04
    done
    printf '\r\033[K\033[?25h'
}
trap '[ -t 1 ] && printf "\033[?25h"' EXIT

W=66   # largura interna das caixas
box_top() { printf '  %s%s%s%s%s\n' "$CYAN" "$G_TL" "$(rep "$G_HH" "$W")" "$G_TR" "$NC"; }
box_bot() { printf '  %s%s%s%s%s\n' "$CYAN" "$G_BL" "$(rep "$G_HH" "$W")" "$G_BR" "$NC"; }
box_row() {     # $1 = texto ja colorido, $2 = largura visivel
    local p=$((W - 4 - $2))
    [ "$p" -lt 0 ] && p=0
    printf '  %s%s%s  %s%*s  %s%s%s\n' "$CYAN" "$G_V" "$NC" "$1" "$p" "" "$CYAN" "$G_V" "$NC"
}
box_lr() {      # $1 = esquerda, $2 = direita, $3 = cor da direita
    local gap=$((W - 4 - ${#1} - ${#2}))
    [ "$gap" -lt 1 ] && gap=1
    box_row "${BOLD}${WHITE}${1}${NC}$(rep ' ' "$gap")${3}${BOLD}${2}${NC}" $((${#1} + gap + ${#2}))
}

show_banner() {
    local cols i grad=(33 39 45 51 50 49)
    cols=$(tput cols 2>/dev/null); [[ "$cols" =~ ^[0-9]+$ ]] || cols=80
    if [ -t 1 ]; then clear 2>/dev/null || printf '\033[2J\033[H'; fi
    echo
    if [ "$UI_UTF8" -eq 1 ] && [ "$cols" -ge 76 ]; then
        for i in "${!BANNER[@]}"; do
            if [ "$NCOLORS" -ge 256 ]; then
                printf '  \033[38;5;%sm%s%s\n' "${grad[i]}" "${BANNER[i]}" "$NC"
            else
                printf '  %s%s%s\n' "$CYAN" "${BANNER[i]}" "$NC"
            fi
        done
    else
        printf '  %s%sV A L I D A T O R%s\n' "$BOLD" "$CYAN" "$NC"
    fi
    printf '  %s%s%s\n' "$GRAY" "$(rep "$G_H" 70)" "$NC"
    printf '  %s%sLABORATÓRIO LINUX%s %s· Deploy Web + DNS · Debian / AlmaLinux · Nota 0 a 8%s\n\n' \
        "$BOLD" "$WHITE" "$NC" "$GRAY" "$NC"
}

###############################################################################
# DISTRIBUICAO
###############################################################################
detect_real_distro() {
    REAL_DISTRO="unknown"
    if [ -r "$RHREL_F" ] && grep -qi 'AlmaLinux' "$RHREL_F"; then
        REAL_DISTRO="almalinux"
    elif [ -e "$ALMAREL_F" ] || { [ -r "$ISSUE_F" ] && grep -qi 'AlmaLinux' "$ISSUE_F"; } ||
         { [ -r "$OSREL_F" ] && grep -Eiq '^ID="?almalinux"?$' "$OSREL_F"; }; then
        REAL_DISTRO="almalinux"
    elif { [ -r "$ISSUE_F" ] && grep -qi 'debian' "$ISSUE_F"; } ||
         { [ -r "$DEBVER_F" ] && ! { [ -r "$OSREL_F" ] && grep -Eiq '^ID="?ubuntu"?$' "$OSREL_F"; }; }; then
        REAL_DISTRO="debian"
    fi
}

select_distro() {
    local choice
    printf '  %s%sQual distribuição Linux você está utilizando?%s\n\n' "$BOLD" "$WHITE" "$NC"
    printf '    %s[1]%s  Debian\n    %s[2]%s  AlmaLinux\n\n' "$GREEN" "$NC" "$CYAN" "$NC"
    while true; do
        read -r -p "  Selecione 1 ou 2: " choice || { echo; echo "Entrada encerrada."; exit 1; }
        case "$choice" in
            1) SELECTED_DISTRO="debian";    DIST_LABEL="Debian";    break ;;
            2) SELECTED_DISTRO="almalinux"; DIST_LABEL="AlmaLinux"; break ;;
            *) printf '  %sOpção inválida. Digite 1 ou 2.%s\n' "$RED" "$NC" ;;
        esac
    done

    detect_real_distro
    if [ "$REAL_DISTRO" != "$SELECTED_DISTRO" ]; then
        printf '\n  %s%s Distribuição selecionada incompatível com este sistema.%s\n' "$RED" "$G_KO" "$NC"
        case "$REAL_DISTRO" in
            debian)    printf '  Sistema identificado: Debian.\n' ;;
            almalinux) printf '  Sistema identificado: AlmaLinux.\n' ;;
            *)         printf '  Não foi possível identificar Debian ou AlmaLinux neste sistema.\n' ;;
        esac
        printf '  Execute novamente e selecione a distribuição correta.\n\n'
        exit 1
    fi
    printf '\n  %s%s%s  Distribuição confirmada: %s%s%s\n' "$GREEN" "$G_OK" "$NC" "$BOLD" "$DIST_LABEL" "$NC"
}

###############################################################################
# DESCOBERTA DE SERVICOS E CONFIGURACAO
###############################################################################
# Resolve o nome canonico de uma unit (ex.: bind9 -> named no Debian).
unit_canon() {
    local n="$1" load id
    load=$(systemctl show -p LoadState --value "$n.service" 2>/dev/null)
    [ "$load" = "loaded" ] || return 1
    id=$(systemctl show -p Id --value "$n.service" 2>/dev/null)
    printf '%s' "${id%.service}"
}

unit_active()  { [ -n "$1" ] && systemctl is-active --quiet "$1" 2>/dev/null; }
unit_enabled() { [ -n "$1" ] && [ "$(systemctl is-enabled "$1" 2>/dev/null)" = "enabled" ]; }

detect_dns_unit() {
    DNS_UNIT=""
    local u c
    for u in named bind9; do
        c=$(unit_canon "$u") && [ -n "$c" ] && { DNS_UNIT="$c"; return; }
    done
}

detect_web_unit() {
    WEB_UNIT=""; WEB_KIND=""
    local cands u c first=""
    if [ "$SELECTED_DISTRO" = "debian" ]; then cands="apache2 nginx"; else cands="httpd nginx"; fi
    for u in $cands; do
        c=$(unit_canon "$u") && [ -n "$c" ] || continue
        if unit_active "$c"; then WEB_UNIT="$c"; break; fi
        [ -z "$first" ] && first="$c"
    done
    [ -z "$WEB_UNIT" ] && WEB_UNIT="$first"
    case "$WEB_UNIT" in
        nginx)         WEB_KIND="nginx" ;;
        apache2|httpd) WEB_KIND="apache" ;;
    esac
}

# Configuracao efetiva do BIND (expande includes e ignora comentarios).
dns_dump() {
    local main
    if [ "$SELECTED_DISTRO" = "debian" ]; then main="$BIND_DEB_DIR/named.conf"; else main="$NAMED_ALMA_CONF"; fi
    if command -v named-checkconf >/dev/null 2>&1; then
        named-checkconf -p "$main" 2>/dev/null && return
    fi
    # Alternativa (ex.: erro de sintaxe): le os arquivos e remove comentarios
    if [ "$SELECTED_DISTRO" = "debian" ]; then
        cat "$BIND_DEB_DIR/named.conf" "$BIND_DEB_DIR/named.conf.options" "$BIND_DEB_DIR/named.conf.local" 2>/dev/null
    else
        cat "$NAMED_ALMA_CONF" "${NAMED_ALMA_CONF%.conf}.rfc1912.zones" 2>/dev/null
    fi | sed -E 's@//.*$@@; s@#.*$@@; s@/\*.*\*/@@g'
}

# Extrai um bloco "algo { ... };" (primeira ocorrencia) em uma unica linha.
named_block() {   # $1 = regex (awk) da linha de abertura
    printf '%s\n' "$DNS_DUMP" | awk -v re="$1" '
        !cap && $0 ~ re { cap = 1 }
        cap { l = $0; print; o += gsub(/\{/, "{", l); c += gsub(/\}/, "}", l); if (o > 0 && o == c) exit }
    ' | tr '\n\t' '  ' | tr -s ' '
}

load_dns_config() {
    DNS_DUMP=$(dns_dump)
    DNS_COMPACT=$(printf '%s' "$DNS_DUMP" | tr '\n\t' '  ' | tr -s ' ')
    LAB_ZONE=$(printf '%s' "$DNS_COMPACT" | grep -Eio 'zone[[:space:]]+"[^"]+\.lab\.?"' | head -n1 | sed -E 's/.*"([^"]+)".*/\1/')
}

# IP do host "ns2" no arquivo da zona informada (bloco compactado em $1)
zone_ns2_ip() {
    local zblk="$1" zfile dir cand d
    zfile=$(printf '%s' "$zblk" | sed -nE 's/.*[[:space:]]file[[:space:]]+"([^"]+)".*/\1/p' | head -n1)
    [ -n "$zfile" ] || return 1
    dir=$(printf '%s' "$OPT_BLK" | sed -nE 's/.*directory[[:space:]]+"([^"]+)".*/\1/p' | head -n1)
    local f=""
    if [ "${zfile:0:1}" = "/" ]; then
        [ -r "$zfile" ] && f="$zfile"
    else
        for d in $dir $ZONE_DIRS; do
            [ -r "$d/$zfile" ] && { f="$d/$zfile"; break; }
        done
    fi
    [ -n "$f" ] || return 1
    awk '{ sub(/;.*/, ""); if (tolower($1) ~ /^ns2([.]|$)/) { for (i = 2; i < NF; i++) if ($i == "A") { print $(i+1); exit } } }' "$f"
}

# $1 = conteudo da lista do allow-transfer; $2 = IP do ns2 (opcional)
transfer_list_ok() {
    local list="${1//\"/}" ns2="$2" tok n=0 t
    local -a toks
    IFS=';' read -ra toks <<< "$list"
    for tok in "${toks[@]}"; do
        t=$(printf '%s' "$tok" | tr -d '[:space:]')
        [ -n "$t" ] || continue
        n=$((n + 1))
        t="${t%/32}"
        if [ "$t" = "none" ]; then
            [ "$n" -eq 1 ] || return 1
            continue
        fi
        [ -n "$ns2" ] && [ "$t" = "$ns2" ] || return 1
    done
    [ "$n" -ge 1 ]
}

###############################################################################
# ITENS DE VALIDACAO
###############################################################################
# 1) IP fixo
check_item1() {
    local ok=0 f uuid type dev method addrs
    if [ "$SELECTED_DISTRO" = "debian" ]; then
        for f in "$IFACES_F" "$IFACES_D"/*; do
            [ -f "$f" ] || continue
            if grep -Ei '^[[:space:]]*iface[[:space:]]+[^[:space:]]+[[:space:]]+inet6?[[:space:]]+static([[:space:]]|$)' "$f" 2>/dev/null |
               grep -Eivq '^[[:space:]]*iface[[:space:]]+lo[[:space:]]'; then
                ok=1; break
            fi
        done
    else
        if command -v nmcli >/dev/null 2>&1; then
            while IFS=: read -r uuid type dev; do
                [ -n "$uuid" ] || continue
                [ "$type" = "loopback" ] && continue
                [ "$dev" = "lo" ] && continue
                method=$(nmcli -g ipv4.method connection show "$uuid" 2>/dev/null | head -n1)
                addrs=$(nmcli -g ipv4.addresses connection show "$uuid" 2>/dev/null | head -n1)
                if [ "$method" = "manual" ] && [ -n "$addrs" ]; then ok=1; break; fi
            done < <(nmcli -t -f UUID,TYPE,DEVICE connection show --active 2>/dev/null)
        fi
        if [ "$ok" -eq 0 ]; then   # alternativa: arquivos ifcfg (legado)
            for f in "$IFCFG_D"/ifcfg-*; do
                [ -f "$f" ] || continue
                [ "${f##*/}" = "ifcfg-lo" ] && continue
                if grep -Eiq '^BOOTPROTO="?(none|static)"?' "$f" && grep -Eq '^IPADDR' "$f"; then ok=1; break; fi
            done
        fi
    fi
    if [ "$ok" -eq 1 ]; then grant 1; else deny 1; fi
}

# 2) Servidor DNS instalado e ativo
check_item2() {
    if unit_active "$DNS_UNIT"; then grant 2; else deny 2; fi
}

# 3) Dominio .lab
check_item3() {
    if [ -n "$LAB_ZONE" ]; then grant 3; else deny 3; fi
}

# 4) Servidor HTTP instalado e ativo
check_item4() {
    if unit_active "$WEB_UNIT"; then grant 4; else deny 4; fi
}

# 5) Template HTML (index.html proprio + outros arquivos/diretorios)
html_ok_in() {
    local d="$1" f="$1/index.html"
    [ -f "$f" ] || return 1
    # pagina padrao do Apache/NGINX nao conta como template publicado
    grep -qiE 'Apache2 (Debian|Ubuntu) Default Page|It works!|Welcome to nginx|HTTP Server Test Page|Test Page for' "$f" && return 1
    find "$d" -mindepth 1 \( -name index.html -o -name index.nginx-debian.html -o -name 404.html \
        -o -name 50x.html -o -name nginx-logo.png -o -name poweredby.png \) -prune -o -print -quit 2>/dev/null | grep -q .
}

check_item5() {
    local dirs d ok=0 r
    dirs="$WEBROOT"
    if [ "$WEB_KIND" = "nginx" ]; then
        dirs="$dirs $NGINX_ROOT"
        if command -v nginx >/dev/null 2>&1; then
            for r in $(nginx -T 2>/dev/null | sed -nE 's/^[[:space:]]*root[[:space:]]+([^;[:space:]]+)[[:space:]]*;.*/\1/p' | sort -u); do
                dirs="$dirs $r"
            done
        fi
    fi
    for d in $dirs; do
        html_ok_in "$d" && { ok=1; break; }
    done
    if [ "$ok" -eq 1 ]; then grant 5; else deny 5; fi
}

# 6) Versao do servidor Web oculta (curl -I; alternativa wget; por fim, config)
fetch_headers() {
    local out=""
    if command -v curl >/dev/null 2>&1; then
        out=$(curl -sI -m 5 http://127.0.0.1/ 2>/dev/null)
    fi
    if ! printf '%s' "$out" | grep -qi '^HTTP/' && command -v wget >/dev/null 2>&1; then
        out=$(wget -S --spider -q -T 5 -t 1 -O /dev/null http://127.0.0.1/ 2>&1)
    fi
    printf '%s' "$out" | tr -d '\r'
}

check_item6() {
    deny 6
    [ -n "$WEB_UNIT" ] && unit_active "$WEB_UNIT" || return 0
    local hdrs srv dir
    hdrs=$(fetch_headers)
    if printf '%s' "$hdrs" | grep -qiE '^[[:space:]]*HTTP/'; then
        srv=$(printf '%s\n' "$hdrs" | grep -iE '^[[:space:]]*Server:' | head -n1)
        if [ -z "$srv" ] || ! printf '%s' "$srv" | grep -qE '[0-9]+\.[0-9]+|/[0-9]|\('; then
            grant 6
        fi
        return 0
    fi
    # Sem resposta HTTP em 127.0.0.1 (ex.: porta alterada): confere a configuracao
    if [ "$WEB_KIND" = "apache" ]; then
        if [ "$WEB_UNIT" = "apache2" ]; then dir="$APACHE_DEB_DIR"; else dir="$APACHE_RH_DIR"; fi
        grep -RIEqs --include='*.conf' '^[[:space:]]*ServerTokens[[:space:]]+Prod(uctOnly)?([[:space:]]|$)' "$dir" && grant 6
    elif [ "$WEB_KIND" = "nginx" ] && command -v nginx >/dev/null 2>&1; then
        nginx -T 2>/dev/null | grep -Eiq '^[[:space:]]*server_tokens[[:space:]]+off[[:space:]]*;' && grant 6
    fi
    return 0
}

# 7) DNS: recursao desativada
check_item7() {
    local scope="$OPT_BLK"
    [ -n "$scope" ] || scope="$DNS_COMPACT"
    if printf '%s' "$scope" | grep -Eiq '(^|[;{}[:space:]])recursion[[:space:]]+no[[:space:]]*;'; then
        grant 7
    else
        deny 7
    fi
}

# 8) DNS: allow-transfer da zona (none, ou IP do ns2 definido no arquivo de zona)
check_item8() {
    deny 8
    [ -n "$LAB_ZONE" ] || return 0
    local zblk list ns2
    zblk=$(named_block "zone[ \t]+\"${LAB_ZONE//./[.]}\"")
    list=$(printf '%s' "$zblk" | sed -nE 's/.*allow-transfer[[:space:]]*\{([^}]*)\}.*/\1/p' | head -n1)
    if [ -z "$list" ]; then   # sem diretiva na zona: vale a global
        list=$(printf '%s' "$OPT_BLK" | sed -nE 's/.*allow-transfer[[:space:]]*\{([^}]*)\}.*/\1/p' | head -n1)
    fi
    [ -n "$list" ] || return 0
    ns2=$(zone_ns2_ip "$zblk")
    transfer_list_ok "$list" "$ns2" && grant 8
    return 0
}

# 9) DNS habilitado na inicializacao
check_item9() {
    if unit_enabled "$DNS_UNIT"; then grant 9; else deny 9; fi
}

# 10) Servidor Web habilitado na inicializacao
check_item10() {
    if unit_enabled "$WEB_UNIT"; then grant 10; else deny 10; fi
}

###############################################################################
# EXECUCAO
###############################################################################
if [ "$(id -u)" -ne 0 ]; then
    printf '\n  %sEste validador precisa ser executado como root (use sudo).%s\n\n' "$RED" "$NC"
    exit 1
fi

show_banner
select_distro

detect_dns_unit
detect_web_unit
load_dns_config
OPT_BLK=$(named_block '^[ \t]*options[ \t]*[{]')

printf '  %sSistema: %s  |  DNS: %s  |  Web: %s%s\n' "$GRAY" "$DIST_LABEL" "${DNS_UNIT:-não encontrado}" "${WEB_UNIT:-não encontrado}" "$NC"
printf '\n  %s%s%s\n' "$BOLD$CYAN" "ANALISANDO O AMBIENTE" "$NC"
printf '  %s%s%s\n' "$GRAY" "$(rep "$G_H" 64)" "$NC"

print_row() {
    local n="$1" s="${SCORES[$1]}" m="${MAXS[$1]}" icon col
    if awk -v s="$s" -v m="$m" 'BEGIN{exit !(s>=m)}'; then icon=$G_OK; col=$GREEN
    elif awk -v s="$s" 'BEGIN{exit !(s>0)}'; then icon=$G_PART; col=$YELLOW
    else icon=$G_KO; col=$RED; fi
    printf '    %s%s%s  %s  %s%s%s\n' "$col" "$icon" "$NC" "$(pad "${LABEL[$n]}" 40)" "$col" "$(fmtn "$s") / $(fmtn "$m")" "$NC"
}

for b in "${!BLK_NAME[@]}"; do
    printf '\n  %s%s%s %s%s%s\n' "$BLUE" "$G_BLK" "$NC" "$BOLD$WHITE" "${BLK_NAME[b]}" "$NC"
    for ((n = BLK_START[b]; n <= BLK_END[b]; n++)); do
        spin "${LABEL[$n]}"
        "check_item$n"
        print_row "$n"
    done
done

# ---------------------------------------------------------------------------
# Pontuacao por bloco e geral
# ---------------------------------------------------------------------------
TOTAL_SUM=$(sum_range 1 "$TOTAL_ITENS")
# TOTAL_PCT: percentual GERAL de conclusao (0-100)
TOTAL_PCT=$(awk -v s="$TOTAL_SUM" -v m="$NOTA_MAXIMA" 'BEGIN{printf "%.1f", (s/m)*100}')

printf '\n  %s%s%s\n' "$BOLD$CYAN" "DESEMPENHO POR BLOCO" "$NC"
printf '  %s%s%s\n' "$GRAY" "$(rep "$G_H" 64)" "$NC"
for b in "${!BLK_NAME[@]}"; do
    bs=$(sum_range "${BLK_START[b]}" "${BLK_END[b]}")
    bm=$(sum_max_range "${BLK_START[b]}" "${BLK_END[b]}")
    bp=$(awk -v s="$bs" -v m="$bm" 'BEGIN{printf "%.1f", (s/m)*100}')
    bar_build "$bp" 24
    printf '    %s %s  %s%s / %s%s\n' "$(pad "${BLK_NAME[b]}" 14)" "$BAR" "$GRAY" "$(fmtn "$bs")" "$(fmtn "$bm")" "$NC"
done

echo
box_top
box_lr "NOTA FINAL" "$(fmtn "$TOTAL_SUM") / $(fmtn "$NOTA_MAXIMA")" "$(awk -v p="$TOTAL_PCT" -v g="$GREEN" -v y="$YELLOW" -v r="$RED" 'BEGIN{ if (p>=100) printf "%s", g; else if (p>=60) printf "%s", y; else printf "%s", r }')"
box_lr "APROVEITAMENTO" "$(printf '%s' "$TOTAL_PCT" | tr '.' ',')%" "$WHITE"
bar_build "$TOTAL_PCT" $((W - 4))
box_row "$BAR" $((W - 4))
box_bot

# ---------------------------------------------------------------------------
# Itens nao validados (somente o assunto, sem dicas)
# ---------------------------------------------------------------------------
PENDING_LIST=()
for ((n = 1; n <= TOTAL_ITENS; n++)); do
    if awk -v s="${SCORES[$n]}" -v m="${MAXS[$n]}" 'BEGIN{exit !(s<m)}'; then
        PENDING_LIST+=("${PEND[$n]}")
    fi
done

echo
if [ "${#PENDING_LIST[@]}" -gt 0 ]; then
    printf '  %s%s%s\n' "$BOLD$YELLOW" "ITENS NÃO VALIDADOS" "$NC"
    for p in "${PENDING_LIST[@]}"; do
        printf '    %s%s%s %s\n' "$YELLOW" "$G_DOT" "$NC" "$p"
    done
else
    printf '  %s%sParabéns! Todos os itens foram validados com sucesso.%s\n' "$GREEN" "$BOLD" "$NC"
fi
printf '\n  %s%s%s\n\n' "$GRAY" "$(rep "$G_H" 64)" "$NC"

###############################################################################
###############################################################################
# ===========================================================================
# A PARTIR DAQUI: PARTE FIXA. NAO ALTERAR ENTRE DESAFIOS.
# (envio da nota, autoexclusao e seguranca). Testada e validada; qualquer
# ajuste aqui deve ser replicado manualmente para o template-fonte da skill.
# ===========================================================================
###############################################################################

###############################################################################
# ENVIO DA NOTA
# - Pergunta se o aluno deseja encerrar e enviar o percentual GERAL
# - Coleta Turma, Nome, E-mail e RM (Data/Hora e gerada pelo servidor da API)
# - Envia por POST para o Web App do Google Apps Script
# - Somente se a API responder "success", o script se auto-exclui
###############################################################################
API_URL="https://script.google.com/macros/s/AKfycbwQxGec6LPqAdP2pbOHjUyOLHRF_Qx_sNgEwex3pZq4DCi6tNhNokl2AnmvzZadMaT9LQ/exec"

# ---------------------------------------------------------------------------
# Localiza o caminho real do proprio binario/script para a autoexclusao.
#
# Quando compilado com shc, $0 preserva exatamente a forma como o binario
# foi invocado (nome nu via PATH, caminho relativo ou caminho absoluto).
# "readlink -f" resolve isso corretamente na maioria dos casos, mas sob
# "sudo" (que pode alterar PATH/cwd) ou em combinacoes especificas de
# shc + distro, $0 isolado pode nao bastar. Por isso tentamos varias
# estrategias em cascata, na ordem mais provavel de sucesso:
#
#   1) readlink -f "$0"                -> cobre caminho absoluto/relativo
#   2) command -v -- "$0" (apos PATH)  -> cobre "$0" sem barra (nome nu)
#   3) basename de "$0" via PATH       -> reforco do caso anterior
#   4) candidatos fixos de instalacao  -> cobre casos em que $0 nao ajuda
#
# NOME_BIN precisa bater com o nome real do binario compilado deste
# desafio (informado no prompt antes de gerar o artefato).
# ---------------------------------------------------------------------------
NOME_BIN="script-validator"
SELF_PATH=""

cand="$(readlink -f "$0" 2>/dev/null)"
[ -n "$cand" ] && [ -f "$cand" ] && SELF_PATH="$cand"

if [ -z "$SELF_PATH" ]; then
    cand="$(command -v -- "$0" 2>/dev/null)"
    cand="$(readlink -f "$cand" 2>/dev/null)"
    [ -n "$cand" ] && [ -f "$cand" ] && SELF_PATH="$cand"
fi

if [ -z "$SELF_PATH" ]; then
    cand="$(command -v -- "$(basename -- "$0")" 2>/dev/null)"
    cand="$(readlink -f "$cand" 2>/dev/null)"
    [ -n "$cand" ] && [ -f "$cand" ] && SELF_PATH="$cand"
fi

if [ -z "$SELF_PATH" ]; then
    for cand in "/usr/local/bin/${NOME_BIN}" "/usr/bin/${NOME_BIN}" \
                "/opt/${NOME_BIN}" "./${NOME_BIN}" "$(pwd)/${NOME_BIN}"; do
        cand="$(readlink -f "$cand" 2>/dev/null)"
        if [ -n "$cand" ] && [ -f "$cand" ]; then
            SELF_PATH="$cand"
            break
        fi
    done
fi

# Nota final = soma dos pontos (0 a 8, ponto decimal, ex.: 6.5)
NOTA_ENVIO="$(awk -v s="$TOTAL_SUM" 'BEGIN{printf "%.1f", s}')"; NOTA_ENVIO="${NOTA_ENVIO//,/.}"

# --- Utilitarios -----------------------------------------------------------
sanitize() {
    printf '%s' "$1" | tr -d '[:cntrl:]' | sed -E 's/^[[:space:]]+//; s/[[:space:]]+$//'
}

json_escape() {
    printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'
}

ask_field() {
    local label="$1" validator="$2" value
    while true; do
        read -r -p "$label: " value || { echo; echo "Entrada encerrada. Saindo sem enviar."; exit 1; }
        value=$(sanitize "$value")
        if "$validator" "$value"; then
            REPLY_FIELD="$value"
            return
        fi
    done
}

# Evita que a planilha interprete o valor como formula (=, +, -, @)
not_formula() { [[ ! "$1" =~ ^[=+@-] ]]; }

val_turma() {
    if [ -z "$1" ] || ! not_formula "$1"; then
        echo -e "  ${RED}Turma invalida. Informe uma turma (nao pode ficar vazia nem iniciar com = + - @).${NC}"
        return 1
    fi
}
val_nome() {
    if [ "${#1}" -lt 5 ] || [[ "$1" != *" "* ]] || ! not_formula "$1"; then
        echo -e "  ${RED}Informe o NOME COMPLETO (nome e sobrenome).${NC}"
        return 1
    fi
}
val_email() {
    if ! [[ "$1" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
        echo -e "  ${RED}E-mail invalido. Exemplo: aluno@dominio.com${NC}"
        return 1
    fi
}
val_rm() {
    if ! [[ "$1" =~ ^[0-9]+$ ]]; then
        echo -e "  ${RED}RM invalido. Digite somente numeros.${NC}"
        return 1
    fi
}

# --- Envio -----------------------------------------------------------------
# Retorna 0 somente se a API respondeu "status":"success"
enviar_para_api() {
    local payload response rc
    payload=$(printf '{"turma":"%s","nome":"%s","email":"%s","rm":"%s","nota":%s}' \
        "$(json_escape "$ALUNO_TURMA")" "$(json_escape "$ALUNO_NOME")" \
        "$(json_escape "$ALUNO_EMAIL")" "$(json_escape "$ALUNO_RM")" \
        "$NOTA_ENVIO")

    if ! command -v curl >/dev/null 2>&1; then
        echo -e "${RED}O comando 'curl' nao esta instalado. Nao foi possivel enviar.${NC}"
        return 1
    fi

    # -L segue o redirect 302 do Apps Script; --data (sem -X POST) faz o curl
    # trocar para GET no redirect, como o Google espera.
    response=$(curl -sS -L -m 30 -H "Content-Type: text/plain" --data "$payload" "$API_URL" 2>&1)
    rc=$?
    if [ "$rc" -ne 0 ]; then
        echo -e "${RED}Falha de rede ao contatar o servidor (codigo $rc).${NC}"
        return 1
    fi
    if echo "$response" | grep -qE '"status"[[:space:]]*:[[:space:]]*"success"'; then
        return 0
    fi
    echo -e "${RED}O servidor nao confirmou o recebimento.${NC}"
    echo "Resposta: $(echo "$response" | head -c 200)"
    return 1
}

# --- Pergunta inicial ------------------------------------------------------
echo -e "${BOLD}Deseja encerrar a tarefa e enviar a nota/percentual atual? [s ou n]${NC}"
while true; do
    read -r -n 1 -p "> " RESP || { echo; echo "Entrada encerrada. Saindo sem enviar."; exit 1; }
    echo
    case "$RESP" in
        [nN])
            echo "Ok! Continue as correcoes e execute o script novamente quando quiser enviar."
            exit 0
            ;;
        [sS])
            break
            ;;
        *)
            echo "Digite 's' para enviar ou 'n' para voltar a tarefa:"
            ;;
    esac
done

# --- Coleta de dados + revisao ---------------------------------------------
while true; do
    echo ""
    echo -e "${BOLD}Preencha seus dados:${NC}"
    ask_field "Turma"                val_turma; ALUNO_TURMA="$REPLY_FIELD"
    ask_field "Nome completo"        val_nome;  ALUNO_NOME="$REPLY_FIELD"
    ask_field "E-mail"               val_email; ALUNO_EMAIL="$REPLY_FIELD"
    ask_field "RM (somente numeros)" val_rm;    ALUNO_RM="$REPLY_FIELD"

    echo ""
    echo -e "${BOLD}Confira os dados:${NC}"
    echo "  Turma : $ALUNO_TURMA"
    echo "  Nome  : $ALUNO_NOME"
    echo "  E-mail: $ALUNO_EMAIL"
    echo "  RM    : $ALUNO_RM"
    echo "  Nota  : ${NOTA_ENVIO//./,} / 8,0"
    echo ""
    echo -e "${YELLOW}Atencao: apos o envio bem-sucedido este script sera excluido.${NC}"

    while true; do
        read -r -n 1 -p "Os dados estao corretos? [s/n] " CONF || { echo; echo "Entrada encerrada. Saindo sem enviar."; exit 1; }
        echo
        case "$CONF" in
            [sS]) CONFIRMADO=1; break ;;
            [nN]) CONFIRMADO=0; break ;;
            *)    echo "Digite 's' para confirmar ou 'n' para digitar novamente." ;;
        esac
    done
    [ "$CONFIRMADO" -eq 1 ] && break
done

# --- Envio com nova tentativa em caso de falha -----------------------------
while true; do
    echo ""
    echo "Enviando dados..."
    if enviar_para_api; then
        echo -e "${GREEN}${BOLD}Nota enviada com sucesso! (${NOTA_ENVIO//./,} / 8,0)${NC}"
        # Autodestruicao somente apos "success"
        if [ -z "$SELF_PATH" ] || [ ! -f "$SELF_PATH" ]; then
            # Ultimo recurso: pergunta o caminho antes de desistir
            echo -e "${YELLOW}Nao foi possivel localizar automaticamente o arquivo (\$0=[$0]).${NC}"
            read -r -p "Informe o caminho completo do binario para excluir (ou Enter para pular): " SELF_PATH
            SELF_PATH="$(readlink -f "$SELF_PATH" 2>/dev/null)"
        fi
        if [ -n "$SELF_PATH" ] && [ -f "$SELF_PATH" ]; then
            rm -f -- "$SELF_PATH" && echo "Este arquivo ($SELF_PATH) foi excluido. Tarefa encerrada." \
                || echo -e "${RED}Falha ao excluir $SELF_PATH. Remova-o manualmente.${NC}"
        else
            echo -e "${RED}Nao foi possivel localizar o arquivo para excluir. Remova-o manualmente (ex.: rm -f /usr/bin/${NOME_BIN}).${NC}"
        fi
        exit 0
    fi
    echo -e "${YELLOW}O script NAO foi excluido e a nota NAO foi registrada.${NC}"
    while true; do
        read -r -n 1 -p "Tentar enviar novamente? [s/n] " RETRY || { echo; exit 1; }
        echo
        case "$RETRY" in
            [sS]) break ;;
            [nN]) echo "Ok. Execute o script novamente quando quiser reenviar."; exit 1 ;;
            *)    echo "Digite 's' para tentar de novo ou 'n' para sair." ;;
        esac
    done
done
