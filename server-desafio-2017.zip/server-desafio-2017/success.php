<?php
// success.php
session_start();

// Trava de segurança: se não estiver logado, volta pro index
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Granted - Auth Cybersecurity</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #000;
            color: #0f0;
            font-family: 'Courier New', Courier, monospace;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        #messageCanvas {
            display: block;
        }
    </style>
</head>
<body>

    <canvas id="messageCanvas"></canvas>

    <script>
        const canvas = document.getElementById('messageCanvas');
        const ctx = canvas.getContext('2d');

        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const text = "Congratulations! You made it.";
        
        // Configurações do grid
        const fontSize = 16;
        const fontFamily = 'Courier New, monospace';
        ctx.font = `bold ${fontSize}px ${fontFamily}`;
        
        // Mede o tamanho que o texto final vai ocupar
        const textMetrics = ctx.measureText(text);
        const textWidth = textMetrics.width;
        const textHeight = fontSize;

        // Posição central do texto
        const startX = (canvas.width - textWidth) / 2;
        const startY = canvas.height / 2;

        const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$%&*';
        const totalChars = text.length;
        
        // Cria um array com as posições corretas de cada caractere
        let charArray = [];
        for (let i = 0; i < totalChars; i++) {
            charArray.push({
                targetX: startX + ctx.measureText(text.substring(0, i)).width,
                targetY: startY,
                char: text[i]
            });
        }

        let animationFrame = 0;
        const animationDuration = 120; // Quanto maior, mais tempo demora para "formar"

        function animate() {
            // Fundo com transparência para criar o rastro de movimento
            ctx.fillStyle = 'rgba(0, 0, 0, 0.15)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            ctx.font = `bold ${fontSize}px ${fontFamily}`;
            
            // Fase 1: Caos inicial (números aleatórios caindo/subindo)
            // Fase 2: Convergência para o texto
            let progress = animationFrame / animationDuration;
            if (progress > 1) progress = 1;

            for (let i = 0; i < totalChars; i++) {
                let target = charArray[i];
                
                // Posição inicial aleatória
                let startXrand = Math.random() * canvas.width;
                let startYrand = Math.random() * canvas.height;

                // Interpolação (Lerp) entre a posição inicial e a final
                let currentX = startXrand + (target.targetX - startXrand) * (progress * progress);
                let currentY = startYrand + (target.targetY - startYrand) * (progress * progress);

                if (progress < 1) {
                    // Enquanto estiver animando, mostra caracteres aleatórios
                    let randomChar = chars.charAt(Math.floor(Math.random() * chars.length));
                    ctx.fillStyle = `rgba(0, 255, 0, ${Math.random() * 0.8 + 0.2})`;
                    ctx.fillText(randomChar, currentX, currentY);
                } else {
                    // Animação finalizada: mostra o texto correto brilhando
                    ctx.fillStyle = '#0F0';
                    ctx.shadowColor = '#0F0';
                    ctx.shadowBlur = 10;
                    ctx.fillText(target.char, target.targetX, target.targetY);
                    ctx.shadowBlur = 0; // Reseta o blur para o próximo loop
                }
            }

            if (animationFrame < animationDuration) {
                animationFrame++;
            }

            requestAnimationFrame(animate);
        }

        animate();
    </script>
</body>
</html>