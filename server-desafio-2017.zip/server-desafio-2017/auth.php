<?php
// auth.php
session_start();

// Inclui as credenciais seguras
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Verifica se o usuário e a senha coincidem com o config.php
    if ($username === $valid_user && $password === $valid_pass) {
        // Sucesso! Cria a sessão e redireciona
        $_SESSION['authenticated'] = true;
        header("Location: success.php");
        exit();
    } else {
        // Falha! Volta para o index com um parâmetro de erro
        header("Location: index.html?error=1");
        exit();
    }
} else {
    // Se tentarem acessar auth.php diretamente, manda de volta pro login
    header("Location: index.html");
    exit();
}
?>