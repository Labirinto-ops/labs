#!/bin/bash

# ==============================================================================
# Script de Instalação: Apache + PHP (via PHP-FPM) no AlmaLinux 9.8
# Descrição: Instala e configura o ambiente web necessário para o desafio.
#            NÃO realiza atualização geral do sistema (apenas instala pacotes).
# ==============================================================================

# Cores para facilitar a leitura do log no terminal
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Função para exibir mensagens de etapa
log_step() {
    echo -e "${GREEN}[+] $1${NC}"
}

# Função para exibir avisos
log_info() {
    echo -e "${YELLOW}[i] $1${NC}"
}

# Verifica se o script está sendo executado como root
if [ "$EUID" -ne 0 ]; then
  echo "Por favor, execute este script como root (use sudo)."
  exit 1
fi

# ------------------------------------------------------------------------------
# ETAPA 1: Instalação do Apache (httpd)
# ------------------------------------------------------------------------------
log_step "Etapa 1/5: Instalando o servidor web Apache (httpd)..."
dnf install -y httpd

# Habilita e inicia o Apache
log_step "Habilitando e iniciando o serviço do Apache..."
systemctl enable httpd
systemctl start httpd

# ------------------------------------------------------------------------------
# ETAPA 2: Adição de Repositórios (EPEL e Remi) para o PHP
# ------------------------------------------------------------------------------
# O AlmaLinux 9 usa o módulo AppStream para PHP, mas para obter a versão 8.3
# (ou superior) e garantir compatibilidade, usamos o repositório Remi.
log_step "Etapa 2/5: Adicionando repositórios EPEL e Remi para o PHP..."
dnf install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-9.noarch.rpm
dnf install -y https://rpms.remirepo.net/enterprise/remi-release-9.rpm

# Habilita o repositório de ferramentas do DNF (necessário para gerenciar módulos)
dnf install -y dnf-utils

# ------------------------------------------------------------------------------
# ETAPA 3: Instalação do PHP e Extensões (PHP-FPM)
# ------------------------------------------------------------------------------
log_step "Etapa 3/5: Instalando PHP 8.3 e extensões via PHP-FPM..."
# Reseta o módulo PHP padrão para evitar conflitos
dnf module reset php -y
# Habilita o módulo PHP 8.3 do Remi
dnf module enable php:remi-8.3 -y

# Instala o PHP-FPM e as extensões essenciais para o desafio
# (incluindo as necessárias para sessões e processamento de strings)
dnf install -y php php-fpm php-cli php-common php-gd php-mbstring php-xml php-opcache php-json

# Habilita e inicia o PHP-FPM
log_step "Habilitando e iniciando o serviço PHP-FPM..."
systemctl enable php-fpm
systemctl start php-fpm

# ------------------------------------------------------------------------------
# ETAPA 4: Configuração da Integração Apache + PHP-FPM
# ------------------------------------------------------------------------------
log_step "Etapa 4/5: Configurando o Apache para usar o PHP-FPM..."

# Cria o arquivo de configuração que faz o Apache encaminhar arquivos .php para o PHP-FPM
# O uso do socket Unix é mais performático que o TCP local.
cat > /etc/httpd/conf.d/php-fpm.conf << 'EOF'
<FilesMatch \.php$>
    SetHandler "proxy:unix:/run/php-fpm/www.sock|fcgi://localhost"
</FilesMatch>
EOF

# Ajusta as permissões do socket do PHP-FPM para que o Apache (usuário 'apache') possa acessá-lo
chown root:apache /run/php-fpm/www.sock 2>/dev/null || true
chmod 660 /run/php-fpm/www.sock 2>/dev/null || true

# Reinicia o Apache para aplicar a nova configuração de handler
systemctl restart httpd

# ------------------------------------------------------------------------------
# ETAPA 5: Configuração de Firewall e SELinux
# ------------------------------------------------------------------------------
log_step "Etapa 5/5: Configurando Firewall e SELinux..."

# Libera as portas HTTP (80) e HTTPS (443) no Firewall
firewall-cmd --permanent --add-service=http
firewall-cmd --permanent --add-service=https
firewall-cmd --reload

# Configura o SELinux para permitir que o Apache faça conexões de rede
# (necessário para o proxy FCGI funcionar)
setsebool -P httpd_can_network_connect on

# Garante que o contexto SELinux do diretório web está correto
restorecon -R /var/www/html

# ------------------------------------------------------------------------------
# VERIFICAÇÃO FINAL
# ------------------------------------------------------------------------------
log_step "Instalação concluída!"
log_info "Verificando os serviços..."

# Exibe o status resumido dos serviços
systemctl is-active httpd && echo " -> Apache está rodando."
systemctl is-active php-fpm && echo " -> PHP-FPM está rodando."

# Exibe a versão do PHP instalada
log_info "Versão do PHP instalada:"
php -v | head -n 1

# Cria um arquivo de teste temporário (phpinfo)
echo "<?php phpinfo(); ?>" > /var/www/html/info.php
log_info "Um arquivo de teste foi criado em /var/www/html/info.php"
log_info "Acesse http://SEU_IP/info.php para confirmar."
log_info "IMPORTANTE: Remova este arquivo após o teste (rm /var/www/html/info.php)."

log_step "Ambiente pronto para receber os arquivos do desafio!"