<?php
// config.php
// As credenciais ficam aqui, isoladas do HTML.
$valid_user = "una";
$valid_pass = "#Tun@rte!2017";
?>